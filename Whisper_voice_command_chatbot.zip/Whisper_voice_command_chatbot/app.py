from flask import Flask, render_template, request, jsonify
import whisper
import os

app = Flask(__name__)
model = whisper.load_model("base")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process-audio', methods=['POST'])
def process_audio():
    audio_file = request.files['audio']
    audio_path = os.path.join('uploads', 'recorded_audio.wav')
    audio_file.save(audio_path)

    # Use Whisper to transcribe the audio
    result = model.transcribe(audio_path, language='ur')
    transcript = result['text']

    # Process the text (e.g., SEO or digital marketing logic)
    response = process_text(transcript)

    return jsonify({'transcript': response})

def process_text(text):
    # Implement your logic here
    return f"Processed: {text}"

if __name__ == '__main__':
    app.run(debug=True)
