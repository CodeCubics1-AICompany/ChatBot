// let mediaRecorder;
// let audioChunks = [];
//
// function startRecording() {
//     navigator.mediaDevices.getUserMedia({ audio: true })
//         .then(stream => {
//             mediaRecorder = new MediaRecorder(stream);
//             mediaRecorder.start();
//
//             mediaRecorder.ondataavailable = event => {
//                 audioChunks.push(event.data);
//             };
//
//             mediaRecorder.onstop = () => {
//                 const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
//                 audioChunks = [];
//
//                 const formData = new FormData();
//                 formData.append('audio', audioBlob, 'recorded_audio.wav');
//
//                 fetch('/process-audio', {
//                     method: 'POST',
//                     body: formData
//                 })
//                 .then(response => response.json())
//                 .then(data => {
//                     console.log(data.transcript);
//                     displayResponse(data.transcript);
//                 });
//             };
//
//             setTimeout(() => {
//                 mediaRecorder.stop();
//             }, 5000); // Stop recording after 5 seconds
//         });
// }
//
// function displayResponse(transcript) {
//     const chatContainer = document.getElementById('chat-container');
//     const botMessage = document.createElement('p');
//     botMessage.textContent = 'Chatbot: ' + transcript;
//     chatContainer.appendChild(botMessage);
// }


// -------------------------

let recognition;
let isRecording = false;

function startVoiceCommand() {
    if (isRecording) {
        recognition.stop();
        return;
    }

    recognition = new webkitSpeechRecognition();
    recognition.continuous = false; // Stops automatically when speech ends
    recognition.interimResults = false;
    recognition.lang = 'ur-PK';

    recognition.onstart = () => {
        isRecording = true;
        document.getElementById('start-btn').innerText = 'Listening...';
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('User said:', transcript);
        processTranscript(transcript);
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        resetRecognition();
    };

    recognition.onend = () => {
        resetRecognition();
    };

    recognition.start();
}

function resetRecognition() {
    isRecording = false;
    document.getElementById('start-btn').innerText = 'Start Voice Command';
    recognition = null;
}

function processTranscript(transcript) {
    // Send the transcript to the backend or process it as needed
    console.log('Processing:', transcript);

    // Display the result in the chat container
    const chatContainer = document.getElementById('chat-container');
    const botMessage = document.createElement('p');
    botMessage.textContent = 'Chatbot: ' + transcript;
    botMessage.classList.add('bot-response');
    chatContainer.appendChild(botMessage);

    // Optionally send the transcript to the server for further processing
}
